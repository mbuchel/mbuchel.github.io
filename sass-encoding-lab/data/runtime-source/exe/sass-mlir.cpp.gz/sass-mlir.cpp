/*
 * SPDX-License-Identifier: AGPL-3.0+
 * Copyright (c) SASS2MLIR Contributors
 */
#include <algorithm>
#include <cctype>
#include <cerrno>
#include <charconv>
#include <common/args.h>
#include <common/corpus.h>
#include <common/disassembler/cubin.h>
#include <common/report.h>
#include <common/thread_pool.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <initializer_list>
#include <mutex>
#include <sass2mlir/dialect/SassValidation.h>
#include <sass2mlir/disassembler/scanner.h>
#include <sass2mlir/pepesilvia/grow.h>
#include <sass2mlir/pepesilvia/module.h>
#include <sass2mlir/plugin.h>
#include <sass2mlir/roundtrip.h>
#include <sass2mlir/validation.h>
#include <set>
#include <spdlog/spdlog.h>
#include <string>
#include <string_view>
#include <system_error>
#include <tqdm.hpp>
#include <unistd.h>
#include <variant>
#include <vector>

#ifdef SASS2MLIR_HAVE_MLIR
#include "llvm/Support/raw_ostream.h"
#include "mlir/Dialect/Arith/IR/Arith.h"
#include "mlir/Dialect/ControlFlow/IR/ControlFlowOps.h"
#include "mlir/Dialect/Func/IR/FuncOps.h"
#include "mlir/Dialect/Math/IR/Math.h"
#include "mlir/Dialect/MemRef/IR/MemRef.h"
#include "mlir/Dialect/SCF/IR/SCF.h"
#include "mlir/Dialect/Vector/IR/VectorOps.h"
#include "mlir/IR/BuiltinOps.h"
#include "mlir/IR/MLIRContext.h"
#include "mlir/IR/OwningOpRef.h"
#include "mlir/IR/Verifier.h"
#include "mlir/Parser/Parser.h"
#include "mlir/Pass/PassManager.h"
#include "mlir/Transforms/Passes.h"
#include <sass2mlir/dialect/SassDialect.h>
#include <sass2mlir/dialect/SassLift.h>
#include <sass2mlir/dialect/SassLower.h>
#include <sass2mlir/dialect/SassPasses.h>
#endif

#ifndef SASS2MLIR_PASS_DIR
#define SASS2MLIR_PASS_DIR "/usr/lib/sass2mlir/passes"
#endif

using namespace sass2mlir;

struct cli_options {
    std::string out;
    std::string passes;
    std::string reference;
    std::string pv_storage = "registers";
    std::string function;
    std::string nvdisasm;
    std::string text_out;
    std::string bin_out;
    std::string mismatch_out;
    std::string unknown_out;
    std::string eval_out;
    std::string builder = "tests/tensormap-spike/fa_tensormap_build.cubin";
    int threads = 1;
    int expect_ldsm = -1;
    int expect_ldgsts = -1;
    int expect_discharged = -1;
    sass::analyze_dump dump;
    rt_mode mode = rt_mode::BOTH;
};

struct cli_option {
    std::string_view name;
    std::variant<std::string*, int*, bool*> value;
    std::initializer_list<std::string_view> commands;
};

static constexpr std::string_view PLUGIN_PREFIX = "sass2mlir-pass-";

/*! \brief Check both the write and close before reporting an output file. */
static bool write_file(const std::filesystem::path& path, const void* data, size_t size)
{
    std::ofstream file(path, std::ios::binary);

    file.write(static_cast<const char*>(data), static_cast<std::streamsize>(size));
    file.close();
    return file.good();
}

static int print_report(const text_report& report)
{
    for (const auto& line : report.info)
        spdlog::info("{}", line);
    for (const auto& line : report.warnings)
        spdlog::warn("{}", line);
    for (const auto& line : report.errors)
        spdlog::error("{}", line);
    return report.failed ? 1 : 0;
}

static bool parse_options(int argc, char** argv, int start, std::string_view command,
                          bool research, cli_options& options,
                          std::string* input = nullptr)
{
    bool psir = false, mlir = false, regen = false;
    cli_option entries[] = {
        {"--out", &options.out, {"lift", "lower", "optimize"}},
        {"--output", &options.out, {"lift", "lower", "optimize"}},
        {"--passes", &options.passes, {"optimize"}},
        {"--reference", &options.reference, {"optimize"}},
        {"--pv-storage", &options.pv_storage, {"optimize"}},
        {"--kernel", &options.function, {"optimize"}},
        {"--fn", &options.function, {}},
        {"--builder", &options.builder, {}},
        {"--threads", &options.threads, {"lift", "verify", "scan"}},
        {"--expect-ldsm", &options.expect_ldsm, {}},
        {"--expect-ldgsts", &options.expect_ldgsts, {}},
        {"--expect-discharged", &options.expect_discharged, {}},
        {"--defuse", &options.dump.defuse, {}},
        {"--reaching", &options.dump.reaching, {}},
        {"--liveness", &options.dump.liveness, {}},
        {"--uniformity", &options.dump.uniformity, {}},
        {"--psir-only", &psir, {"verify"}},
        {"--mlir-only", &mlir, {"verify"}},
        {"--regen", &regen, {"verify"}},
        {"--nvdisasm", &options.nvdisasm, {"scan"}},
        {"--text-out", &options.text_out, {"scan"}},
        {"--bin-out", &options.bin_out, {"scan"}},
        {"--mismatch-out", &options.mismatch_out, {"scan"}},
        {"--unknown-out", &options.unknown_out, {"scan"}},
        {"--eval-out", &options.eval_out, {"scan"}},
    };

    for (int i = start; i < argc; ++i) {
        std::string_view arg = argv[i];
        auto entry = std::find_if(std::begin(entries), std::end(entries),
                                  [&](const cli_option& entry) {
                                      return arg == entry.name;
                                  });
        const char* end;
        std::from_chars_result parsed;
        std::string** string;
        int** number;
        bool** flag;

        if (entry == std::end(entries)) {
            if (input && !arg.empty() && arg[0] != '-' && input->empty()) {
                *input = arg;
                continue;
            }
            spdlog::error("unexpected argument: {}", arg);
            return false;
        }
        if (!research && std::find(entry->commands.begin(), entry->commands.end(),
                                   command) == entry->commands.end()) {
            spdlog::error("{} does not accept {}; run sass-mlir {} --help", command,
                          arg, command);
            return false;
        }
        flag = std::get_if<bool*>(&entry->value);
        if (flag) {
            **flag = true;
            continue;
        }
        string = std::get_if<std::string*>(&entry->value);
        number = std::get_if<int*>(&entry->value);
        if (++i == argc || (string && std::strncmp(argv[i], "--", 2) == 0) ||
            (command == "scan" && (argv[i][0] == '-' || argv[i][0] == '\0'))) {
            spdlog::error("{} needs a value", arg);
            return false;
        }
        if (string) {
            **string = argv[i];
            continue;
        }
        end = argv[i] + std::strlen(argv[i]);
        parsed = std::from_chars(argv[i], end, **number);
        if (parsed.ec != std::errc{} || parsed.ptr != end) {
            spdlog::error("{} needs an integer, got {}", arg, argv[i]);
            return false;
        }
    }
    if (options.threads < 1) {
        spdlog::error("--threads must be at least 1");
        return false;
    }
    if (psir + mlir + regen > 1) {
        spdlog::error("--psir-only, --mlir-only and --regen are mutually exclusive");
        return false;
    }
    options.mode = psir    ? rt_mode::PSIR_ONLY
                   : mlir  ? rt_mode::MLIR_ONLY
                   : regen ? rt_mode::REGEN
                           : rt_mode::BOTH;
    return true;
}

static int inspect_cmd(const std::string& input)
{
    std::vector<std::filesystem::path> paths = collect_cubins(input);
    int failures = 0;

    if (paths.empty()) {
        spdlog::error("no cubins under {}", input);
        return 2;
    }
    for (const auto& path : paths) {
        sass_cubin cubin = {};
        if (!parse_cubin(path.string(), cubin)) {
            spdlog::error("cannot read cubin: {}", path.string());
            ++failures;
            continue;
        }
        spdlog::info("{}: SM{}, {} kernels", path.string(), cubin.sm,
                     cubin.sections.size());
        for (const auto& section : cubin.sections)
            spdlog::info("  {}  ({} instructions)", section.name,
                         section.bytes.size() / 16);
    }
    return failures ? 1 : 0;
}

static void plugin_usage(const std::string& command)
{
    if (command == "plugins")
        std::puts("Usage: sass-mlir plugins [--plugins-dir directory]");
    else if (command == "intercept")
        std::puts(
            "Usage: sass-mlir intercept <plugin> [--plugins-dir directory] -- <program> [args...]");
    else
        std::puts(
            "Usage: sass-mlir plugin <plugin> <cubin-or-directory> [--plugins-dir directory]\n"
            "Runs plugin callbacks. Module replacements are written to <input>.rewritten.\n"
            "Instruction callbacks report changes; their ASTs are not emitted.");
}

static std::filesystem::path plugin_path(const std::string& directory,
                                         const std::string& name)
{
    if (name.find('/') != std::string::npos)
        return name;
    return std::filesystem::path(directory) /
           (name.ends_with(".so") ? name : std::string(PLUGIN_PREFIX) + name + ".so");
}

static int list_plugins(const std::string& directory)
{
    std::error_code error;
    std::filesystem::directory_iterator entries(directory, error);

    if (error) {
        spdlog::error("cannot read plugin directory {}: {}", directory,
                      error.message());
        return 1;
    }
    for (const auto& entry : entries) {
        std::string name = entry.path().filename().string();
        loaded_plugin plugin = {};
        std::string message;

        if (!name.starts_with(PLUGIN_PREFIX) || !name.ends_with(".so"))
            continue;
        if (!load_plugin(entry.path().string(), plugin, message)) {
            spdlog::warn("{}: {}", name, message);
            continue;
        }
        spdlog::info(
            "{}\t{}",
            name.substr(PLUGIN_PREFIX.size(), name.size() - PLUGIN_PREFIX.size() - 3),
            plugin.pass->description);
        unload_plugin(plugin);
    }
    return 0;
}

static int intercept(const std::filesystem::path& library, char* const argv[])
{
    const char* previous = std::getenv("LD_PRELOAD");
    std::string preload = std::filesystem::absolute(library).string();

    if (!std::filesystem::is_regular_file(library)) {
        spdlog::error("plugin not found: {}", library.string());
        return 1;
    }
    if (previous && *previous)
        preload += std::string(":") + previous;
    if (setenv("LD_PRELOAD", preload.c_str(), 1) != 0) {
        spdlog::error("cannot set LD_PRELOAD: {}", std::strerror(errno));
        return 1;
    }
    execvp(argv[0], argv);
    spdlog::error("cannot execute {}: {}", argv[0], std::strerror(errno));
    return 127;
}

static int run_plugin(const std::filesystem::path& library, const std::string& input)
{
    std::vector<std::filesystem::path> paths = collect_cubins(input);
    loaded_plugin plugin = {};
    std::string error;
    size_t seen = 0, changed = 0, undecodable = 0, failures = 0;

    if (paths.empty()) {
        spdlog::error("no cubins under {}", input);
        return 1;
    }
    if (!load_plugin(library.string(), plugin, error)) {
        spdlog::error("{}: {}", library.string(), error);
        return 1;
    }
    for (const auto& path : paths) {
        std::ifstream stream(path, std::ios::binary);
        std::vector<uint8_t> image((std::istreambuf_iterator<char>(stream)), {});
        sass_cubin cubin = {};
        plugin_result result;
        std::filesystem::path output = path.string() + ".rewritten";

        if (stream.bad() || !parse_cubin_mem(image.data(), image.size(), cubin)) {
            spdlog::error("cannot read cubin: {}", path.string());
            ++failures;
            continue;
        }
        result = apply_plugin(*plugin.pass, cubin, image);
        seen += result.seen;
        changed += result.changed;
        undecodable += result.undecodable;
        if (!result.error.empty()) {
            spdlog::error("{}: {}", path.string(), result.error);
            ++failures;
        }
        if (result.image.empty())
            continue;
        if (!write_file(output, result.image.data(), result.image.size())) {
            spdlog::error("cannot write {}", output.string());
            ++failures;
            continue;
        }
        spdlog::info("wrote {} ({} -> {} bytes)", output.string(), image.size(),
                     result.image.size());
    }
    unload_plugin(plugin);
    spdlog::info(
        "cubins={} instructions={} reported_changes={} undecodable={} failures={}",
        paths.size(), seen, changed, undecodable, failures);
    return failures ? 1 : 0;
}

static int plugin_cmd(int argc, char** argv)
{
    std::string command = argv[0];
    std::string directory = SASS2MLIR_PASS_DIR;
    std::vector<std::string> positional;
    int program = argc;
    bool launch = command == "intercept";

    for (int i = 1; i < argc; ++i)
        if (std::strcmp(argv[i], "--") == 0) {
            program = i + 1;
            break;
        }
    sass2mlir_args_common(program == argc ? argc : program - 1,
                          const_cast<const char**>(argv));
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];

        if (arg == "--help" || arg == "-h") {
            plugin_usage(command);
            return 0;
        }
        if (arg == "--") {
            if (launch && i + 1 < argc)
                break;
            spdlog::error("-- requires an intercepted program");
            return 2;
        }
        if (arg == "--plugins-dir") {
            if (++i == argc || argv[i][0] == '-') {
                spdlog::error("--plugins-dir needs a directory");
                return 2;
            }
            directory = argv[i];
        } else if (!arg.empty() && arg[0] != '-')
            positional.push_back(arg);
        else {
            spdlog::error("unknown option: {}", arg);
            return 2;
        }
    }
    if (command == "plugins" && positional.empty())
        return list_plugins(directory);
    if (launch && positional.size() == 1 && program < argc)
        return intercept(plugin_path(directory, positional[0]), argv + program);
    if (command == "plugin" && positional.size() == 2)
        return run_plugin(plugin_path(directory, positional[0]), positional[1]);
    plugin_usage(command);
    return 2;
}

static void scan_usage()
{
    spdlog::info(
        "usage: sass-mlir scan <cubin-or-dir> [--nvdisasm <path>]\n"
        "                         [--text-out <dir>] [--bin-out <dir>]\n"
        "                         [--mismatch-out <file>] [--unknown-out <file>]\n"
        "                         [--eval-out <file>] [--threads <n> (default: 1)]\n"
        "\n"
        "Disassembles every cubin with nvdisasm and with the generated\n"
        "per-SM tables, and reports how many instructions the tables\n"
        "handle. UNKNOWN means our decoder failed. nvdisasm_hidden\n"
        "counts silent interior PCs; boundary silence is unobserved.\n"
        "Binary output preserves every section byte, including tails.\n"
        "--unknown-out reports counts by opcode and classification.");
    sass2mlir_args_help();
}

static int scan_cmd(const std::string& input, const cli_options& options)
{
    std::vector<std::filesystem::path> cubins;
    sass2mlir::scan_counts counts = {};
    sass2mlir::sass_thread_pool pool = {};
    tq::progress_bar bar;
    std::mutex progress_lock;
    size_t done = 0;
    bool show_bar = ::isatty(STDERR_FILENO);

    if (input.empty()) {
        spdlog::error("no cubin or directory given");
        scan_usage();
        return 2;
    }

    try {
        if (std::filesystem::is_directory(input)) {
            for (const auto& e : std::filesystem::recursive_directory_iterator(input))
                if (e.is_regular_file())
                    cubins.push_back(e.path());
        } else if (std::filesystem::is_regular_file(input)) {
            cubins.push_back(input);
        } else {
            spdlog::error("input is not a file or directory: {}", input);
            return 2;
        }
        std::sort(cubins.begin(), cubins.end());
        if (!options.text_out.empty())
            std::filesystem::create_directories(options.text_out);
        if (!options.bin_out.empty())
            std::filesystem::create_directories(options.bin_out);
    } catch (const std::filesystem::filesystem_error& error) {
        spdlog::error("{}", error.what());
        return 2;
    }

    if (show_bar) {
        bar.set_ostream(std::cerr);
        bar.set_prefix("scan ");
        bar << ("0/" + std::to_string(cubins.size()) + " cubins");
        bar.update(cubins.empty() ? 1.0 : 0.0);
    }

    sass2mlir::pool_start(pool, options.threads);
    counts = sass2mlir::parallel_map_reduce(
        pool, cubins,
        [&](const std::filesystem::path& path) -> sass2mlir::scan_counts {
            sass2mlir::scan_counts local = {};

            try {
                if (!sass2mlir::scan_cubin(path, input, options.nvdisasm,
                                           options.text_out, options.bin_out, local)) {
                    spdlog::warn("scan failed: {}", path.string());
                    ++local.failed;
                }
            } catch (const std::exception& error) {
                spdlog::error("{}: {}", path.string(), error.what());
                ++local.failed;
            }
            if (show_bar) {
                std::lock_guard<std::mutex> lock(progress_lock);

                bar << (std::to_string(++done) + "/" + std::to_string(cubins.size()) +
                        " cubins");
                bar.update(static_cast<double>(done) / cubins.size());
            }
            return local;
        },
        sass2mlir::scan_counts{}, sass2mlir::merge_scan_counts);
    sass2mlir::pool_stop(pool);

    if (show_bar) {
        bar.update(1.0);
        std::cerr << '\n';
    }

    print_report(sass2mlir::summarize_scan(counts));

    if (!options.mismatch_out.empty()) {
        if (!sass2mlir::scan_write_mismatches(options.mismatch_out,
                                              counts.mismatches)) {
            spdlog::error("cannot write {}", options.mismatch_out);
            ++counts.failed;
        } else
            spdlog::info("{} distinct mismatches -> {}", counts.mismatches.size(),
                         options.mismatch_out);
    }

    if (!options.unknown_out.empty()) {
        if (!sass2mlir::scan_write_unknowns(options.unknown_out, counts.unknowns)) {
            spdlog::error("cannot write {}", options.unknown_out);
            ++counts.failed;
        } else
            spdlog::info("{} distinct unknown opcodes -> {}", counts.unknowns.size(),
                         options.unknown_out);
    }

    if (!options.eval_out.empty()) {
        if (!sass2mlir::scan_write_eval(options.eval_out, counts.per_sm)) {
            spdlog::error("cannot write {}", options.eval_out);
            ++counts.failed;
        } else
            spdlog::info("{} SM rows -> {}", counts.per_sm.size(), options.eval_out);
    }
    return sass2mlir::scan_passed(counts) ? 0 : 1;
}

static void roundtrip_cubin(const std::filesystem::path& path,
                            const std::filesystem::path&, rt_mode mode,
                            roundtrip_counts& c)
{
    sass_cubin cubin = {};
    pepesilvia::ps_module ps;
    std::string label = path.filename().string();
    size_t failures_before = c.failures;
    size_t words = 0;

    if (!parse_cubin(path.string(), cubin)) {
        ++c.unparsed;
        audit_report(c, label + ": parse_cubin failed");
        return;
    }
    words = check_psir_roundtrip(cubin, mode, label, ps, c);
    if (words == 0 || mode == rt_mode::PSIR_ONLY)
        return;
#ifdef SASS2MLIR_HAVE_MLIR
    check_mlir_roundtrip(cubin, ps, mode, words, label, c);
    if (mode != rt_mode::REGEN && c.failures == failures_before)
        spdlog::info("OK {} sections={} words={}", label, cubin.sections.size(), words);
#else
    (void)failures_before;
#endif
}

/*! \brief Run a corpus audit and print its combined report. */
template <class Counts, class Worker, class Summary, class... Args>
static int corpus_cmd(const std::string& input, unsigned threads, Worker worker,
                      Summary summary, const Args&... args)
{
    std::vector<Counts> partial;

    if (!run_cubins(input, threads, partial, worker, args...))
        return 2;
    return print_report(summary(partial));
}

static int grow_cmd(const std::string& input, const std::string& out,
                    const std::string& builder_path, const std::string& fn_pattern)
{
    sass_cubin cubin = {}, builder = {}, again = {};
    pepesilvia::grow_result result = {};
    std::string error;
    std::vector<std::string> notes;
    std::ifstream f(input, std::ios::binary);
    std::vector<uint8_t> image((std::istreambuf_iterator<char>(f)),
                               std::istreambuf_iterator<char>());
    bool ok = false;

    if (image.empty() || out.empty()) {
        spdlog::error("grow: unreadable input or missing --out");
        return 2;
    }
    if (!parse_cubin_mem(image.data(), image.size(), cubin)) {
        spdlog::error("grow: {}: not a parseable cubin", input);
        return 1;
    }
    if (!parse_cubin(builder_path, builder)) {
        spdlog::error("grow: {}: builder cubin unparseable", builder_path);
        return 1;
    }
    ok = pepesilvia::grow_tensormap_image(cubin, builder, fn_pattern, result, error);
    for (const auto& note : result.notes)
        spdlog::info("{}", note);
    if (!ok) {
        spdlog::error("{}", error);
        return 1;
    }
    if (!write_file(out, result.image.data(), result.image.size())) {
        spdlog::error("grow: cannot write {}", out);
        return 1;
    }
    spdlog::info("grow: {}: {} words ({} bytes) -> {} ({} bytes), "
                 "prologue {} words",
                 result.section_name, result.original_words, result.original_words * 16,
                 out, result.section_bytes, result.prologue_words);
    if (!parse_cubin(out, again)) {
        spdlog::error("grow: audit: the written cubin does not re-parse");
        return 1;
    }
    ok = pepesilvia::audit_tensormap_growth(cubin, again, result, notes, error);
    for (const auto& note : notes)
        spdlog::info("{}", note);
    if (!ok) {
        spdlog::error("{}", error);
        return 1;
    }
    spdlog::info("grow: OK");
    return 0;
}

#ifdef SASS2MLIR_HAVE_MLIR

static mlir::OwningOpRef<mlir::ModuleOp>
parse_module(const std::string& path, mlir::MLIRContext& ctx,
             const char* verification_error = "verification failed")
{
    mlir::OwningOpRef<mlir::ModuleOp> mod;

    ctx.loadDialect<sass::SassDialect, mlir::arith::ArithDialect,
        mlir::cf::ControlFlowDialect, mlir::func::FuncDialect,
        mlir::math::MathDialect, mlir::memref::MemRefDialect,
        mlir::scf::SCFDialect, mlir::vector::VectorDialect>();
    mod = mlir::parseSourceFile<mlir::ModuleOp>(path, &ctx);
    if (!mod)
        spdlog::error("{}: parse failed", path);
    else if (mlir::failed(mlir::verify(*mod))) {
        spdlog::error("{}: {}", path, verification_error);
        return {};
    }
    return mod;
}

/* See docs/source/exe/sass-mlir/mlir_io.cpp.md#note-1. */
static int parse_check(const std::string& path)
{
    mlir::MLIRContext ctx;
    mlir::OwningOpRef<mlir::ModuleOp> mod;
    mlir::OwningOpRef<mlir::ModuleOp> again;
    std::string first;
    llvm::raw_string_ostream os(first);
    std::string second;
    llvm::raw_string_ostream os2(second);

    mod = parse_module(path, ctx);
    if (!mod)
        return 1;

    mod->print(os);
    os.flush();

    again = mlir::parseSourceString<mlir::ModuleOp>(first, &ctx);

    if (!again) {
        spdlog::error("{}: re-parse of the printed form failed", path);
        return 1;
    }

    again->print(os2);
    os2.flush();

    if (first != second) {
        spdlog::error("{}: print/parse round-trip is not stable", path);
        llvm::errs() << "--- first print ---\n"
                     << first << "--- second print ---\n"
                     << second;
        return 1;
    }

    llvm::outs() << first;
    return 0;
}

/*! \brief Checks that decoder architecture names exist in the generated enum. */
static int check_arch()
{
    if (!sass::sass_arch_tables_ok()) {
        spdlog::error("SassArch names do not match decoder tables");
        return 1;
    }
    spdlog::info("SassArch names match decoder tables");
    return 0;
}

static std::filesystem::path mlir_out_path(const std::filesystem::path& path,
                                           const std::filesystem::path& root,
                                           bool single,
                                           const std::filesystem::path& out)
{
    std::filesystem::path rel =
        single ? path.filename() : std::filesystem::relative(path, root);

    rel.replace_extension(".mlir");
    return out / rel;
}

static int lift_cmd(const std::string& input, const std::string& out_dir,
                    unsigned threads)
{
    std::filesystem::path root = input;
    bool single = std::filesystem::is_regular_file(root);
    std::vector<std::filesystem::path> cubins = collect_cubins(root);
    sass_thread_pool pool;
    std::vector<std::string> texts(cubins.size());
    std::vector<int> status(cubins.size(), 0);
    size_t done = 0;
    size_t failed = 0;
    size_t empty = 0;

    if (cubins.empty()) {
        spdlog::error("no cubins under {}", input);
        return 2;
    }
    if (!single && out_dir.empty()) {
        spdlog::error("lift of a directory needs --out");
        return 2;
    }

    pool_start(pool, threads);
    parallel_for(pool, cubins.size(), [&](size_t i, size_t) {
        sass_cubin cubin = {};
        pepesilvia::ps_module ps;
        mlir::MLIRContext ctx;
        bool skipped = false;
        mlir::OwningOpRef<mlir::ModuleOp> module;
        llvm::raw_string_ostream os(texts[i]);

        ctx.getOrLoadDialect<sass::SassDialect>();
        module = sass::lift_cubin_file(cubins[i], ctx, &cubin, &ps, &skipped);

        if (skipped) {
            status[i] = 1;
            return;
        }
        if (!module) {
            status[i] = 2;
            return;
        }
        if (mlir::failed(mlir::verify(*module))) {
            status[i] = 4;
            return;
        }
        if (cubin.sections.empty())
            status[i] = 3;
        module->print(os);
    });
    pool_stop(pool);

    for (size_t i = 0; i < cubins.size(); ++i) {
        if (status[i] == 1) {
            spdlog::error("{}: no decoder table for this SM", cubins[i].string());
            ++failed;
            continue;
        }
        if (status[i] == 3)
            ++empty;
        if (status[i] == 2) {
            spdlog::error("{}: parse or lift failed", cubins[i].string());
            ++failed;
            continue;
        }
        if (status[i] == 4) {
            spdlog::error("{}: MLIR verification failed", cubins[i].string());
            ++failed;
            continue;
        }
        if (out_dir.empty()) {
            if (std::fwrite(texts[i].data(), 1, texts[i].size(), stdout) !=
                    texts[i].size() ||
                std::fflush(stdout) != 0) {
                spdlog::error("{}: stdout write failed", cubins[i].string());
                ++failed;
                continue;
            }
        } else {
            std::filesystem::path out = mlir_out_path(cubins[i], root, single, out_dir);
            std::error_code error;

            std::filesystem::create_directories(out.parent_path(), error);
            if (error) {
                spdlog::error("{}: write failed: {}", out.string(), error.message());
                ++failed;
                continue;
            }
            if (!write_file(out, texts[i].data(), texts[i].size())) {
                spdlog::error("{}: write failed", out.string());
                ++failed;
                continue;
            }
        }
        ++done;
    }

    if (!out_dir.empty())
        spdlog::info("lifted={} empty={} failed={}", done, empty, failed);
    return failed != 0 ? 1 : 0;
}

/*! \brief A file-safe section name: the ".text." prefix dropped, every
 * remaining non-alphanumeric run flattened to '_'. */
static std::string bin_name(const std::string& section)
{
    std::string name = section;

    if (name.rfind(".text.", 0) == 0)
        name.erase(0, 6);
    for (char& ch : name)
        if (!std::isalnum(static_cast<unsigned char>(ch)))
            ch = '_';
    return name;
}

/* See docs/source/exe/sass-mlir/mlir_io.cpp.md#note-2. */
static std::string bin_name_capped(const std::string& section)
{
    std::string name = bin_name(section);

    if (name.size() + 4 > 255) {
        uint64_t h = 1469598103934665603ULL;
        char hex[17];

        for (char ch : name)
            h = (h ^ static_cast<unsigned char>(ch)) * 1099511628211ULL;
        std::snprintf(hex, sizeof(hex), "%016llx", static_cast<unsigned long long>(h));
        name = name.substr(0, 234) + "-" + hex;
    }
    return name;
}

/*! \brief The lower subcommand: parses the module and writes each
 * sass.func's lowered section bytes as <out>/<section>.bin. */
static int lower_cmd(const std::string& file, const std::string& out_dir)
{
    mlir::MLIRContext ctx;
    mlir::OwningOpRef<mlir::ModuleOp> mod;
    std::vector<sass::sass_lowered_section> sections;
    std::vector<sass::sass_lower_word> words;
    std::set<std::string> output_names;
    std::error_code error;
    size_t unencodable = 0;

    mod = parse_module(file, ctx, "MLIR verification failed");
    if (!mod)
        return 1;

    sections = sass::lower_module(*mod, &words);
    unencodable =
        std::count(words.begin(), words.end(), sass::sass_lower_word::UNREGENERABLE);
    if (unencodable != 0) {
        spdlog::error("{}: cannot encode {} instruction words", file, unencodable);
        return 1;
    }
    if (sections.empty()) {
        spdlog::error("{}: no kernel sections could be lowered", file);
        return 1;
    }
    for (const auto& sec : sections) {
        std::string name = bin_name_capped(sec.name) + ".bin";

        if (!output_names.insert(name).second) {
            spdlog::error("{}: duplicate output filename {}", file, name);
            return 1;
        }
    }

    std::filesystem::create_directories(out_dir, error);
    if (error) {
        spdlog::error("{}: write failed: {}", out_dir, error.message());
        return 1;
    }
    for (const auto& sec : sections) {
        std::filesystem::path out =
            std::filesystem::path(out_dir) / (bin_name_capped(sec.name) + ".bin");

        if (!write_file(out, sec.bytes.data(), sec.bytes.size())) {
            spdlog::error("{}: write failed", out.string());
            return 1;
        }
        spdlog::info("{} {}: {} bytes", out.string(), sec.name, sec.bytes.size());
    }
    return 0;
}

static int opt_cmd(const std::string& path)
{
    mlir::MLIRContext ctx;
    mlir::OwningOpRef<mlir::ModuleOp> mod;
    mlir::PassManager pm(&ctx);

    mod = parse_module(path, ctx);
    if (!mod)
        return 1;

    pm.addPass(mlir::createCSEPass());
    pm.addPass(mlir::createCanonicalizerPass());
    if (mlir::failed(pm.run(*mod))) {
        spdlog::error("{}: pass run failed", path);
        return 1;
    }
    mod->print(llvm::outs());
    return 0;
}

static bool optimize_temporary(const std::string& path, const void* data, size_t size,
                               std::string& temporary)
{
    std::string pattern = path + ".tmp.XXXXXX";
    std::vector<char> name(pattern.begin(), pattern.end());
    FILE* file;
    int fd;
    bool okay;

    name.push_back('\0');
    fd = mkstemp(name.data());
    if (fd < 0)
        return false;
    temporary = name.data();
    file = fdopen(fd, "wb");
    if (!file) {
        close(fd);
        std::remove(temporary.c_str());
        return false;
    }
    okay = std::fwrite(data, 1, size, file) == size;
    okay = std::fclose(file) == 0 && okay;
    if (!okay)
        std::remove(temporary.c_str());
    return okay;
}

static bool optimize_publish(const std::string& path, const void* data, size_t size,
                             const std::string& contract)
{
    std::string image_temp, contract_temp;
    std::string sidecar = path + ".launch.json";
    std::error_code error;
    bool okay = false;

    if (!optimize_temporary(path, data, size, image_temp))
        return false;
    if (!contract.empty() && !optimize_temporary(sidecar, contract.data(), contract.size(), contract_temp))
        goto cleanup;
    if (std::rename(image_temp.c_str(), path.c_str()) != 0)
        goto cleanup;
    if (contract.empty()) {
        std::filesystem::remove(sidecar, error);
        okay = !error;
    } else {
        okay = std::rename(contract_temp.c_str(), sidecar.c_str()) == 0;
    }
cleanup:
    std::remove(image_temp.c_str());
    if (!contract_temp.empty())
        std::remove(contract_temp.c_str());
    return okay;
}

static int optimize_file(const std::string& input, const std::string& kernel_pattern,
                         const std::string& passes, const std::string& out,
                         const std::string& reference, attention_p_strategy strategy)
{
    std::ifstream f(input, std::ios::binary);
    std::vector<char> image((std::istreambuf_iterator<char>(f)),
                            std::istreambuf_iterator<char>());
    sass2mlir::sass_mlir_rewrite res;

    if (image.empty()) {
        spdlog::error("optimize: unreadable input {}", input);
        return 2;
    }
    res = sass2mlir::sass_rewrite_kernel_image_mlir(image.data(), image.size(),
                                                    kernel_pattern, passes, reference, strategy);
    if (!res.err.empty()) {
        spdlog::error("optimize: {}", res.err);
        return 1;
    }
    spdlog::info("optimize: matched={} changed={} words_changed={}",
                 res.sections_matched, res.sections_changed, res.words_changed);
    if (!res.report.empty())
        spdlog::info("report:\n{}", res.report);
    if (res.sections_matched == 0) {
        spdlog::error(
            "no kernel matches '{}'; use 'sass-mlir inspect {}' to list kernels",
            kernel_pattern, input);
        return 1;
    }
    if (!res.program.empty()) {
        if (!res.image.empty() || !res.launch_contract.empty() ||
            std::filesystem::path(out).extension() != ".mlir") {
            spdlog::error("source-program output requires a .mlir path and cannot carry a cubin or launch contract");
            return 1;
        }
        if (!optimize_publish(out, res.program.data(), res.program.size(), {})) {
            spdlog::error("optimize: cannot publish source program {}", out);
            return 1;
        }
        return 0;
    }
    if (passes == "flash-attention-program") {
        spdlog::error("source-program pass produced no MLIR; refusing to publish the input cubin");
        return 1;
    }
    if (!out.empty()) {
        const char* output = res.image.empty()
                                 ? image.data()
                                 : reinterpret_cast<const char*>(res.image.data());
        size_t output_size = res.image.empty() ? image.size() : res.image.size();

        if (!optimize_publish(out, output, output_size, res.launch_contract)) {
            spdlog::error("optimize: {}: image or launch contract publication failed", out);
            return 1;
        }
    }
    return 0;
}

/*! \brief Whether one directory contains the other. */
static bool directories_overlap(const std::filesystem::path& first,
                                const std::filesystem::path& second)
{
    auto mismatch =
        std::mismatch(first.begin(), first.end(), second.begin(), second.end());

    return mismatch.first == first.end() || mismatch.second == second.end();
}

static int optimize_cmd(const std::string& input, const cli_options& options)
{
    std::error_code error;
    std::filesystem::path source;
    std::filesystem::path output = options.out;
    std::filesystem::path source_resolved, output_resolved;
    std::vector<std::filesystem::path> paths;
    std::string kernel = options.function.empty() ? ".text." : options.function;
    bool single = false;
    int failures = 0;
    attention_p_strategy strategy = attention_p_strategy::registers;

    if (options.pv_storage != "registers" && options.pv_storage != "shared" &&
        options.pv_storage != "shared-whole") {
        spdlog::error("invalid --pv-storage: expected registers|shared|shared-whole");
        return 2;
    }
    if (options.pv_storage != "registers") {
        if (options.passes != "flash-attention-resynth" || options.reference.empty()) {
            spdlog::error("shared P storage requires --passes flash-attention-resynth and --reference");
            return 2;
        }
        strategy = options.pv_storage == "shared-whole" ?
                   attention_p_strategy::shared_whole : attention_p_strategy::shared;
    }
    if (options.passes.empty()) {
        spdlog::error("choose passes with --passes, for example: "
                      "sass-mlir optimize {} --passes hgmma",
                      input);
        return 2;
    }
    source = std::filesystem::absolute(input, error).lexically_normal();
    if (error) {
        spdlog::error("cannot resolve input: {}", error.message());
        return 2;
    }
    if (source.filename().empty() && source != source.root_path())
        source = source.parent_path();
    single = std::filesystem::is_regular_file(source, error);
    if (output.empty()) {
        output = source;
        if (single)
            output.replace_extension(options.passes == "flash-attention-program" ?
                ".attention.mlir" : ".optimized.cubin");
        else
            output += ".optimized";
    } else if (single && std::filesystem::is_directory(output, error)) {
        output /= source.filename();
        if (options.passes == "flash-attention-program")
            output.replace_extension(".attention.mlir");
    }
    if (!single) {
        source_resolved = std::filesystem::weakly_canonical(source, error);
        if (error) {
            spdlog::error("cannot resolve input directory: {}", error.message());
            return 2;
        }
        output_resolved = std::filesystem::weakly_canonical(output, error);
        if (error) {
            spdlog::error("cannot resolve output directory: {}", error.message());
            return 2;
        }
        if (directories_overlap(source_resolved, output_resolved)) {
            spdlog::error("input and output directories must not contain each other");
            return 2;
        }
    }
    paths = collect_cubins(source);
    if (paths.empty()) {
        spdlog::error("no cubins under {}", input);
        return 2;
    }
    for (const auto& path : paths) {
        std::filesystem::path destination =
            single ? output : output / std::filesystem::relative(path, source);

        if (options.passes == "flash-attention-program" && !single)
            destination.replace_extension(".attention.mlir");
        if (std::filesystem::equivalent(path, destination, error)) {
            spdlog::error("output must differ from input: {}", path.string());
            return 2;
        }
        if (!destination.parent_path().empty()) {
            error.clear();
            std::filesystem::create_directories(destination.parent_path(), error);
            if (error) {
                spdlog::error("cannot create output directory: {}", error.message());
                return 2;
            }
        }
        if (optimize_file(path.string(), kernel, options.passes,
                          destination.string(), options.reference, strategy) != 0) {
            ++failures;
            continue;
        }
        spdlog::info("wrote {}", destination.string());
    }
    return failures ? 1 : 0;
}

static void analyze_input(const std::filesystem::path& path,
                          const std::filesystem::path& root,
                          const sass::analyze_dump& dump, sass::analyze_counts& counts)
{
    sass::analyze_cubin(path, root, dump, llvm::outs(), counts);
}

static int desc_selftest()
{
    return print_report(sass::summarize_gmma_desc(sass::validate_gmma_desc()));
}

static void symaddr_print_function(const sass::symaddr_function_report& report)
{
    if (report.ldsm != 0 || report.ldgsts != 0)
        spdlog::info("fn {}: ldsm={}/{} ldgsts={}/{}", report.name.substr(0, 90),
                     report.ldsm_resolved, report.ldsm, report.ldgsts_resolved,
                     report.ldgsts);
    if (!report.first_refused.empty())
        spdlog::info("first-refused: {}", report.first_refused.substr(0, 400));
}

/* See docs/source/exe/sass-mlir/symaddr.cpp.md#note-3. */
static int symaddr_cmd(const std::string& input, int expect_ldsm, int expect_ldgsts)
{
    std::filesystem::path root = input;
    std::vector<std::filesystem::path> cubins = collect_cubins(root);
    sass::symaddr_counts total;

    if (cubins.empty()) {
        spdlog::error("no cubins under {}", input);
        return 2;
    }
    for (const auto& p : cubins)
        sass::symaddr_cubin(p, root, total, symaddr_print_function);

    return print_report(sass::summarize_symaddr(total, expect_ldsm, expect_ldgsts));
}

#endif

static int research_cmd(std::string_view command, const std::string& input,
                        const cli_options& options)
{

#ifdef SASS2MLIR_HAVE_MLIR
    if (command == "parse-check")
        return parse_check(input);
    if (command == "check-arch")
        return check_arch();
    if (command == "desc-selftest")
        return desc_selftest();
    if (command == "symaddr")
        return symaddr_cmd(input, options.expect_ldsm, options.expect_ldgsts);
    if (command == "opt")
        return opt_cmd(input);
    if (command == "analyze") {
        const auto& dump = options.dump;
        unsigned threads =
            dump.defuse || dump.reaching || dump.liveness || dump.uniformity
                ? 1
                : options.threads;

        return corpus_cmd<sass::analyze_counts>(input, threads, analyze_input,
                                                sass::summarize_analysis, dump);
    }
    if (command == "check-tma")
        return tma_rewrite_run(input, options.threads, options.function,
                               options.expect_discharged);
    if (command == "check-hgmma")
        return hgmma_rewrite_run(input, options.threads, options.function);
    if (command == "warpsplit")
        return warpsplit_run(input, options.threads, options.function);
    if (command == "pc-convert")
        return pc_convert_run(input, options.threads, options.function, options.out);
#endif
    if (command == "remap-selftest")
        return corpus_cmd<remap_self_counts>(input, options.threads, audit_remap_cubin,
                                             summarize_remap);
    if (command == "nvinfo-check")
        return corpus_cmd<nvinfo_counts>(input, options.threads, audit_nvinfo_cubin,
                                         summarize_nvinfo);
    if (command == "cubin-write")
        return corpus_cmd<cubin_write_counts>(input, options.threads, audit_cubin_write,
                                              summarize_cubin_write);
    if (command == "grow") {
        if (options.function.empty()) {
            spdlog::error("grow requires --function");
            return 2;
        }
        return grow_cmd(input, options.out, options.builder, options.function);
    }
    spdlog::error("unknown research command: {}", command);
    return 2;
}

static void usage(std::string_view command)
{
    if (command == "research") {
        std::puts("Usage: sass-mlir research <command> [input] [options]\n"
                  "  analyze, check-hgmma, check-tma, symaddr\n"
                  "  pc-convert, warpsplit, grow, opt\n"
                  "  parse-check, check-arch, desc-selftest, remap-selftest\n"
                  "  nvinfo-check, cubin-write\n"
                  "See docs/cli.md for command arguments and experiment limits.");
        return;
    }
    if (command == "scan") {
        scan_usage();
        return;
    }
    if (command == "lift") {
        std::puts("Usage: sass-mlir lift <cubin-or-directory> [--out directory]\n"
                  "       [--threads N]\n"
                  "Prints MLIR for a single cubin; a directory requires --out.");
        return;
    }
    if (command == "lower") {
        std::puts("Usage: sass-mlir lower <file.mlir> [--out directory]\n"
                  "Writes each kernel's section bytes as a .bin file.\n"
                  "Default output: current directory.");
        return;
    }
    if (command == "optimize") {
        std::puts(
            "Usage: sass-mlir optimize <cubin-or-directory> --passes <list>\n"
            "       [--kernel substring] [--out path] [--reference cubin]\n"
            "       [--pv-storage registers|shared|shared-whole]\n"
            "With flash-attention-resynth, --reference supplies the pinned FA3 ABI and target layouts.\n"
            "flash-attention-target prepares the full FA3 reference tree and launch sidecar before conversion.\n"
            "Select fma-fuse, deftz, uniform, hgmma, tma, flash-attention, pc; execution follows that order.\n"
            "flash-attention-resynth lowers source-owned attention IR into a fresh 512-thread kernel.\n"
            "flash-attention-program constructs the complete logical attention program and emits .mlir.\n"
            "Use flash-attention-resynth to lower that program and emit a cubin plus launch sidecar.\n"
            "These attention passes are exclusive and require --reference.\n"
            "Shared P storage writes <out>.launch.json with its expanded shared-memory requirement.\n"
            "Default output: <name>.optimized.cubin or <directory>.optimized/.");
        return;
    }
    if (command == "verify") {
        std::puts("Usage: sass-mlir verify <cubin-or-directory> [--threads N]\n"
                  "       [--psir-only | --mlir-only | --regen]\n"
                  "Checks encoding round trips without GPU execution.");
        return;
    }
    if (command == "inspect") {
        std::puts("Usage: sass-mlir inspect <cubin-or-directory>");
        return;
    }
    std::puts("Usage: sass-mlir <command> <input> [options]\n"
              "\n"
              "  inspect   List kernels and their architecture\n"
              "  lift      Convert cubins to MLIR\n"
              "  lower     Convert MLIR to kernel section bytes\n"
              "  optimize  Apply selected passes and write a cubin\n"
              "  verify    Check encoding round trips (no GPU execution)\n"
              "  passes    List available optimization passes\n"
              "  scan      Compare decoding and encoding against nvdisasm\n"
              "  plugin    Run an ABI plugin on cubins offline\n"
              "  intercept Run a program with an ABI plugin preloaded\n"
              "  plugins   List installed ABI plugins\n"
              "  research  Diagnostics and experiments; use research --help\n"
              "\n"
              "Examples:\n"
              "  sass-mlir inspect kernel.cubin\n"
              "  sass-mlir optimize kernel.cubin --passes hgmma\n"
              "  sass-mlir verify kernel.optimized.cubin\n"
              "\n"
              "Options:\n"
              "  --passes list       Select fma-fuse, deftz, uniform, hgmma, tma, flash-attention, pc\n"
              "                      Or flash-attention-resynth (exclusive; see optimize --help)\n"
              "  --kernel substring  Select kernels (default: all)\n"
              "  --out path          Output file or directory\n"
              "  --threads N         Corpus workers (default: 1)\n"
              "\n"
              "Optimize defaults to <name>.optimized.cubin for a file,\n"
              "or <input>.optimized/ for a directory. See docs/cli.md for\n"
              "configuration limits and advanced research commands.");
}

static int verify(const std::string& input, const cli_options& options)
{
    sass2mlir::rt_mode mode = options.mode;

#ifndef SASS2MLIR_HAVE_MLIR
    if (mode == rt_mode::MLIR_ONLY || mode == rt_mode::REGEN) {
        spdlog::error("MLIR verification requires an MLIR build");
        return 2;
    }
    mode = rt_mode::PSIR_ONLY;
#endif
    return corpus_cmd<roundtrip_counts>(
        input, options.threads, roundtrip_cubin,
        [mode](const std::vector<roundtrip_counts>& partial) {
            return summarize_roundtrip(partial, mode);
        },
        mode);
}

int main(int argc, char** argv)
{
    cli_options options = {};
    std::string_view command = argc > 1 ? argv[1] : "";
    bool research = command == "research";
    int command_index = research ? 2 : 1;
    int input_index = command_index + 1;
    std::string input;
    bool no_input = false;
    bool scan = command == "scan";

    if (command == "plugin" || command == "plugins" ||
        command == "intercept")
        return plugin_cmd(argc - 1, argv + 1);
    sass2mlir_args_common(argc, const_cast<const char**>(argv));
    if (argc == 1 || std::any_of(argv + 1, argv + argc, [](const char* arg) {
            return std::strcmp(arg, "--help") == 0 || std::strcmp(arg, "-h") == 0;
        })) {
        usage(command);
        return 0;
    }
    if (command_index >= argc) {
        spdlog::error("research requires a command; see docs/cli.md");
        return 2;
    }
    command = argv[command_index];
    if (!research && command != "inspect" &&
        command != "optimize" && command != "verify" &&
        command != "lift" && command != "lower" &&
        command != "passes" && !scan) {
        spdlog::error("unknown command: {}; run sass-mlir --help", command);
        return 2;
    }
    no_input = command == "passes" ||
               (research && (command == "check-arch" ||
                             command == "desc-selftest"));
    if (!no_input && !scan && (input_index >= argc || argv[input_index][0] == '-')) {
        spdlog::error("{} requires an input file or directory", command);
        return 2;
    }
    if (!no_input && !scan)
        input = argv[input_index];
    if (!parse_options(argc, argv, input_index + (!no_input && !scan), command,
                       research, options, scan ? &input : nullptr))
        return 2;
    if (scan)
        return scan_cmd(input, options);
    if (research)
        return research_cmd(command, input, options);
    if (command == "inspect")
        return inspect_cmd(input);
    if (command == "verify")
        return verify(input, options);
#ifdef SASS2MLIR_HAVE_MLIR
    if (command == "lift")
        return lift_cmd(input, options.out, options.threads);
    if (command == "lower")
        return lower_cmd(input, options.out.empty() ? "." : options.out);
    if (command == "optimize")
        return optimize_cmd(input, options);
    if (command == "passes") {
        std::puts(
            "fma-fuse Contract plain FMUL/FADD into FFMA (permits fused rounding)\n"
            "deftz    Remove FFMA flush-to-zero modifiers\n"
            "uniform  Move eligible warp-uniform values to uniform registers\n"
            "hgmma    Convert eligible matrix operations to HGMMA\n"
            "tma      Analyze TMA address contracts\n"
            "flash-attention  Convert supported fp16 SM90 attention staging to TMA\n"
            "flash-attention-resynth  Lower source attention into fresh GPU code; requires --reference\n"
            "flash-attention-program  Construct source-owned logical attention MLIR\n"
            "flash-attention-target   Prepare the FA3 target reference; requires --reference\n"
            "pc       Same conversion (research name)\n"
            "\nPasses execute in the listed order; repeated names execute again.\n"
            "HGMMA also enables uniformization and spill elimination when UMOV is available.");
        return 0;
    }
#else
    if (command == "lift" || command == "lower" ||
        command == "optimize" || command == "passes") {
        spdlog::error("{} requires an MLIR build", command);
        return 2;
    }
#endif
    spdlog::error("unknown command: {}; run sass-mlir --help", command);
    return 2;
}
