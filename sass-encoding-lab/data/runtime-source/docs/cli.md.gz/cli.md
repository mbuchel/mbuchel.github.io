# Command line

Use `sass-mlir` as the entry point.
```sh
build/sass-mlir inspect kernel.cubin
build/sass-mlir lift kernel.cubin --out ir
build/sass-mlir lower ir/kernel.mlir --out bins
build/sass-mlir optimize kernel.cubin --passes hgmma
build/sass-mlir verify kernel.optimized.cubin
```

`inspect` lists architecture and kernel names. `optimize` applies the selected
passes and writes a cubin. `verify` checks encoding round trips without running
on a GPU. Inspection, lifting, optimization, and verification also accept an input directory.
`lift` prints MLIR for a single input unless `--out` is given; directory lifting
requires `--out`. `lower` writes each text section as a `.bin` file.

The default output is `kernel.optimized.cubin` for a file and `<input>.optimized/`
for a directory. Use `--out` to choose another location. For a single input, an
existing output directory receives the input filename. Directory input and output
trees must be separate, including when paths use symlinks. An unchanged matched
kernel still produces an output file; the report states how many sections changed.
A kernel filter matching nothing is an error.

```sh
build/sass-mlir optimize kernel.cubin --passes hgmma,tma \
  --kernel flash --out candidate.cubin
build/sass-mlir passes
```

`--kernel` matches a substring of the kernel or section name; omitting it selects
all text sections. `--passes` selects from `fma-fuse`, `deftz`, `uniform`, `hgmma`,
`tma`, and `flash-attention` (`pc` is the research name for the same pass).
Passes execute in the order supplied; repeated names execute again. Each HGMMA
stage runs its uniformization and spill-elimination prerequisites when the
architecture has UMOV. Reports follow execution order. Config-file support for
this CLI remains to be implemented. Sequential edits compose through the shared
[instruction layout](development/instruction-layout.md); unmappable metadata or
unencodable instructions refuse publication. GPU correctness and timing are separate
work.

`flash-attention-resynth` is an exclusive image pass for the reviewed causal and
noncausal fp16 D64 SM90 programs. It requires FA3 instruction recipes:

```sh
build/sass-mlir optimize original.cubin --passes flash-attention-resynth \
  --reference fa3.cubin --kernel SOURCE_SYMBOL --out converted.cubin
```

Select exactly one admitted section with `--kernel`. This pass now generates the
complete selected 512-thread body from the admitted FA2 program. The pinned FA3
reference provides instruction recipes for source normalization and an ABI
container; its selected executable body is replaced entirely. The output has
a canonical `.launch.json` contract with `lowering=source-program`, finite
FP16 Q/K/V inputs, and automatic causal register-P/noncausal shared-P storage.
The typed adapter uses 90,240/196,736 bytes of dynamic shared memory respectively.
GPU correctness and performance remain unvalidated for this fresh route.

The [revision21 measurements](flash-attention/source-512-timings-20261001-native-program-21-full.md)
describe the earlier retained-scaffold route and remain historical controls.
Generic preload requires the supported typed launch adapter.

`flash-attention-program` constructs the complete logical attention program
from the admitted source, then applies the QK/PV overlap and persistent-work
passes. It also lowers fresh producer/consumer control flow, matrix and scalar
instructions, and output stores. Physical allocation and ordinary completion
checks run before its inspectable MLIR is printed:

```sh
build/sass-mlir optimize original.cubin --passes flash-attention-program \
  --reference fa3.cubin --kernel SOURCE_SYMBOL --out attention.mlir
build/sass-mlir research parse-check attention.mlir
```

Its default output is `original.attention.mlir`; an explicit output must have
the `.mlir` extension. The reference is currently required for the preceding
source HGMMA normalization. The new program builder receives no target
function. This diagnostic output retains logical bodies and publication markers;
it has no launch contract and `lower` refuses it. Use `flash-attention-resynth`
to finalize the selected machine function and publish its cubin. See the
[pass design and implemented checks](flash-attention/source-program-passes-20261001.md).

`fma-fuse` is an explicit opt-in to fused rounding: FMUL followed by FADD can
produce a different numerical result after contraction to FFMA. It is not
enabled by default; host validation does not prove GPU execution or scoreboard
progress. See [FMA ownership and validation](development/fma-mlir-consolidation.md).

`verify` defaults to one worker; `--threads N` changes that count. Image
optimization processes files serially. `--output` aliases `--out`. Commands reject
irrelevant or malformed options. Use `sass-mlir optimize --help` (or another
command's help) for its exact arguments.

## Research tools

Diagnostics and experiments use an explicit `research` prefix. They are separate
from the normal optimization workflow:

```sh
build/sass-mlir research analyze kernel.cubin --liveness
build/sass-mlir research check-hgmma kernel.cubin
```

- `analyze` accepts `--defuse`, `--reaching`, `--liveness`, and `--uniformity`.
- `check-hgmma` and `check-tma` report transformation eligibility. They replace the
  old `hgmma-rewrite` and `tma-rewrite` diagnostic commands.
- `pc-convert`, `warpsplit`, and `grow` retain experiment-specific
  output contracts used by the replay documentation.
- `parse-check`, `check-arch`, `desc-selftest`, `symaddr`, `remap-selftest`,
  `nvinfo-check`, and `cubin-write` support internal regression checks.
- `opt` invokes generic MLIR cleanup on a textual MLIR file.

The obsolete `deftz`, `dce`, `spill-elim`, `uniform`, `regalloc`, `tma`, and
`warpspec` experiment commands and their CLI implementations were deleted. Their
old command names are not compatibility aliases. The core preprocessing and
optimization implementations remain under `dialect/lib/passes/`.

Old top-level research commands are no longer accepted. `verify` replaces the
old `roundtrip` command and keeps its `--psir-only`, `--mlir-only`, and `--regen`
modes. Unsupported architectures, empty inputs, failed encoding merges, and
nonidentical regeneration are errors. `--regen` counts raw preservation separately
from encoding success; equal disassembly text does not excuse changed bytes.
`undecoded` means our decoder could not decode a word, not that nvdisasm hid it.
Tail bytes are counted and preserved. See [instruction statistics](probes/opcode-census.md)
for the distinction between probe-table counts and observed cubin words.

The obsolete separate HGMMA audit implementation was removed; HGMMA
optimization lives under `dialect/lib/passes/`.

## Scanner and ABI plugins

The scanner and plugin launcher now use the same executable:

```sh
build/sass-mlir scan kernel.cubin --threads 1 --eval-out /tmp/eval.tsv
build/sass-mlir plugins --plugins-dir build
build/sass-mlir plugin nop-count kernel.cubin --plugins-dir build
build/sass-mlir intercept /path/to/sass2mlir-pass-transplant.so -- ./application
```

`scan` compares decoder and encoder output with nvdisasm. It defaults to one
worker and preserves the existing census schema, including hidden interior PCs,
unobserved boundary PCs, malformed references, and trailing bytes. See the
[scanner reference](probes/scanner.md) for the denominators and exit criteria.

`plugins` lists ABI plugins from the install directory or `--plugins-dir`.
`plugin` invokes their module and instruction callbacks on existing cubins.
Only module callbacks supply replacement bytes, written to `<input>.rewritten`;
instruction callbacks report changes without emitting their edited ASTs.
`intercept` preloads a plugin into the named program. Everything after `--`
is passed to that program unchanged, including `--help` and `--version`.

`sass2mlir.cpp` and `sass2mlir-scanner.cpp` and their executable targets were
removed. There are no compatibility launchers. The project and plugin ABI names
remain `sass2mlir`; `passes` lists MLIR transformations, while `plugins` lists
runtime shared libraries.

The source directory has four transformation/integration groups under `passes/`:
`fa-tensormap`, `fuse`, `kernel-rewrite`, and `transplant`. FMA contraction lives
in the shared MLIR pipeline; the separate `fma-fuse` plugin was removed. For
preload use, select `SASS2MLIR_PASS=fma-fuse` and an explicit `SASS2MLIR_KERNEL`
filter with the `kernel-rewrite` plugin. Diagnostics
live in `diagnostics/`. Model implementations and support code live together
under `passes/transplant/`; their shared-library names are preserved.

The experimental [flash-attention pass](flash-attention/pass.md) requires its
captured launch ABI and modified replay launcher; rewriting the cubin alone
does not adapt an application launch.
