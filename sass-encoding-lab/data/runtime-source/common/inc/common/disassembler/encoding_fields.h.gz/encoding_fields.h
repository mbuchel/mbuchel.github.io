/* SPDX-License-Identifier: AGPL-3.0+ */
#ifndef COMMON_DISASSEMBLER_ENCODING_FIELDS_H
#define COMMON_DISASSEMBLER_ENCODING_FIELDS_H
#include <cstdint>

#define SASS_CONTROL_FIELDS(F) \
    F(inst, 0, 0, 12) \
    F(pred, 0, 12, 4) \
    F(pm, 1, 38, 2) \
    F(stalls, 1, 41, 4) \
    F(yield, 1, 45, 1) \
    F(write_barrier, 1, 46, 3) \
    F(read_barrier, 1, 49, 3) \
    F(barrier_mask, 1, 52, 6) \
    F(reuse, 1, 58, 4) \
    F(rsv, 1, 62, 2)
#define SASS_REGISTER8_FIELDS(F) \
    F(slot16, 0, 16, 8) \
    F(slot24, 0, 24, 8) \
    F(slot32, 0, 32, 8) \
    F(slot64, 1, 0, 8)
#define SASS_PREDICATE3_FIELDS(F)                                                      \
    F(slot81, 1, 17, 3)                                                                \
    F(slot87, 1, 23, 3)
#define SASS_BYTE_SELECTOR_VALUES(V) \
    V(whole, "") V(b1, ".B1") V(b2, ".B2") V(b3, ".B3")
#define SASS_HALF_SELECTOR_VALUES(V) \
    V(whole, "") V(f32, ".F32") V(h0_h0, ".H0_H0") V(h1_h1, ".H1_H1")
#define SASS_OPERAND_FLAG_FIELDS(F)                                                    \
    F(abs_62, 0, 62, 1, "|")                                                           \
    F(neg_63, 0, 63, 1, "-")                                                           \
    F(neg_72, 1, 8, 1, "-")                                                            \
    F(abs_73, 1, 9, 1, "|")                                                            \
    F(neg_75, 1, 11, 1, "-")                                                           \
    F(bnot_63, 0, 63, 1, "~")                                                          \
    F(bnot_72, 1, 8, 1, "~")                                                           \
    F(bnot_75, 1, 11, 1, "~")                                                          \
    F(pred_neg_90, 1, 26, 1, "!")
#define SASS_OPERAND_SELECTOR_FIELDS(F) \
    F(byte_76, encoding_byte_selector, 1, 12, 2, encoding_byte_tokens) \
    F(half_60, encoding_half_selector, 0, 60, 2, encoding_half_tokens) \
    F(half_81, encoding_half_selector, 1, 17, 2, encoding_half_tokens)

#define SASS_FIELD_PREFIX_0(offset) uint64_t : offset;
#define SASS_FIELD_PREFIX_1(offset) uint64_t : 64; uint64_t : offset;
#define SASS_ENCODING_MEMBER(name, half, offset, width, ...) \
    struct { SASS_FIELD_PREFIX_##half(offset) uint64_t name : width; };
#define SASS_ENCODING_TRAIT(name, half, offset, width, ...) \
    inline static constexpr encoding_field name = {half * 64 + offset, width};

namespace sass2mlir {
#define SASS_FIELD_ID(name, ...) name,
#define SASS_SELECTOR_ID(name, type, ...) name,
enum class encoding_field_id : uint8_t {
    dynamic = 0,
    SASS_REGISTER8_FIELDS(SASS_FIELD_ID)
    SASS_OPERAND_FLAG_FIELDS(SASS_FIELD_ID)
    SASS_OPERAND_SELECTOR_FIELDS(SASS_SELECTOR_ID)
    SASS_PREDICATE3_FIELDS(SASS_FIELD_ID)
    count
};
#undef SASS_FIELD_ID
#undef SASS_SELECTOR_ID

struct encoding_field {
    uint8_t lo;
    uint8_t width;
};
union encoding_control_view {
    uint64_t enc[2];
    SASS_CONTROL_FIELDS(SASS_ENCODING_MEMBER)
};
union encoding_register8_view {
    uint64_t enc[2];
    SASS_REGISTER8_FIELDS(SASS_ENCODING_MEMBER)
};

union encoding_predicate_view {
    uint64_t enc[2];
    SASS_PREDICATE3_FIELDS(SASS_ENCODING_MEMBER)
};
#define SASS_SELECTOR_ENUM(name, token) name,
enum class encoding_byte_selector : uint64_t {
    SASS_BYTE_SELECTOR_VALUES(SASS_SELECTOR_ENUM)
};
enum class encoding_half_selector : uint64_t {
    SASS_HALF_SELECTOR_VALUES(SASS_SELECTOR_ENUM)
};
#undef SASS_SELECTOR_ENUM
#define SASS_SELECTOR_TOKEN(name, token) token,
inline constexpr const char* encoding_byte_tokens[] = {
    SASS_BYTE_SELECTOR_VALUES(SASS_SELECTOR_TOKEN)};
inline constexpr const char* encoding_half_tokens[] = {
    SASS_HALF_SELECTOR_VALUES(SASS_SELECTOR_TOKEN)};
#undef SASS_SELECTOR_TOKEN
#define SASS_SELECTOR_MEMBER(name, type, half, offset, width, tokens) \
    struct { SASS_FIELD_PREFIX_##half(offset) type name : width; };
union encoding_operand_modifier_view {
    uint64_t enc[2];
    SASS_OPERAND_FLAG_FIELDS(SASS_ENCODING_MEMBER)
    SASS_OPERAND_SELECTOR_FIELDS(SASS_SELECTOR_MEMBER)
};
#undef SASS_SELECTOR_MEMBER
struct encoding_control_fields {
    SASS_CONTROL_FIELDS(SASS_ENCODING_TRAIT)
};
struct encoding_register8_fields {
    SASS_REGISTER8_FIELDS(SASS_ENCODING_TRAIT)
};

struct encoding_predicate_fields {
    SASS_PREDICATE3_FIELDS(SASS_ENCODING_TRAIT)
};
#define SASS_SELECTOR_TRAIT(name, type, half, offset, width, tokens) \
    SASS_ENCODING_TRAIT(name, half, offset, width)
struct encoding_operand_modifier_fields {
    SASS_OPERAND_FLAG_FIELDS(SASS_ENCODING_TRAIT)
    SASS_OPERAND_SELECTOR_FIELDS(SASS_SELECTOR_TRAIT)
};
#undef SASS_SELECTOR_TRAIT
#define SASS_REGISTER_TRAIT(name, ...) encoding_register8_fields::name,
#define SASS_PREDICATE_TRAIT(name, ...) encoding_predicate_fields::name,
#define SASS_FLAG_TRAIT(name, ...) encoding_operand_modifier_fields::name,
#define SASS_SELECTOR_FIELD(name, type, ...) encoding_operand_modifier_fields::name,
inline constexpr encoding_field encoding_named_fields[] = {
    {0, 0},
    SASS_REGISTER8_FIELDS(SASS_REGISTER_TRAIT)
    SASS_OPERAND_FLAG_FIELDS(SASS_FLAG_TRAIT)
    SASS_OPERAND_SELECTOR_FIELDS(SASS_SELECTOR_FIELD)
    SASS_PREDICATE3_FIELDS(SASS_PREDICATE_TRAIT)
};
#undef SASS_REGISTER_TRAIT
#undef SASS_PREDICATE_TRAIT
#undef SASS_FLAG_TRAIT
#undef SASS_SELECTOR_FIELD

inline constexpr const encoding_field* encoding_field_for(encoding_field_id id)
{
    unsigned index = static_cast<unsigned>(id);

    return index && index < static_cast<unsigned>(encoding_field_id::count)
               ? &encoding_named_fields[index] : nullptr;
}
} // namespace sass2mlir
#undef SASS_ENCODING_TRAIT
#undef SASS_ENCODING_MEMBER
#undef SASS_FIELD_PREFIX_0
#undef SASS_FIELD_PREFIX_1
#endif
